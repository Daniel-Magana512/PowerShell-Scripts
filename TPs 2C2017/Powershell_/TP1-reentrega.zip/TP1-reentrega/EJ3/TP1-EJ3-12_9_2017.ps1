#TP1 
#Ejercicio 2
#Autor/es= Wawreniuk Cesar
#
#Comision= 1333, (lunes y miercoles de 8 a 12 hs)


####### PARAMETROS
# valido los parametros, en general
param(   [parameter( Mandatory=$true, Position=0)][ValidateScript({test-path $_  })][string]$path_export,
         [parameter(  Mandatory=$false, Position=1,HelpMessage="DEBE INGRESAR UN NUMERO")]
         [ValidateScript({$_ -ge 0 })] [double]$porcentaje_libre=-1,
         [parameter(ValueFromRemainingArguments=$true)] $resto=$NULL

       
          ) 

# valido los parametros, especificamente 
# si resto distinto a null, hay parametros de mas y debe informar y salir
$inicio_resto=$FALSE
if($resto -eq $NULL)
{
$inicio_resto=$TRUE
}


####### FUNCIONES

Function exportar-CSV($path)
{


#$fp="C:\Users\Paula\Desktop\trompeta.csv"


# obtengo los atributos que pide que guarde en el archivo
$a=Get-WmiObject win32_logicaldisk -filter drivetype=3|select-object -property @{name= "Unidad"; expression={$_.deviceid}},@{name="Capacidad_Total"; expression={$_.size}},@{name="Espacio_Ocupado"; expression={($_.size-$_.freespace)}}                         

# cargo el archivo con los atributos que obtuve
$a|export-csv $path -NoTypeInformation

}	


Function importar-CSV($path, $p_l)
{

# importo los datos en una variable
#$b = import-csv $path  
#$c=$b
# cargo el archivo con los atributos calculados
# recorro archivo linea * linea
foreach($linea in import-csv $path )
{

    # calculo porcentaje de espacio libre
    # si capacidad es cero, le doy cero al porcentaje
    $ll=$linea.Capacidad_Total
   
    if($ll -gt 0)
    {
    $porcentaje=((($linea.Capacidad_Total-$linea.Espacio_Ocupado))*100)/($linea.Capacidad_Total)
    }
    else
    {
    $porcentaje=0
    }
    
# pego los carteles, cambio de color si porcentaje menor a porcentaje_libre
if($porcentaje -gt $porcentaje_libre)
{   
write-host $linea.Unidad  $linea.Capacidad_Total $porcentaje
}
else
{
# porcentaje libre menor al parametro enviado
write-host $linea.Unidad  $linea.Capacidad_Total $porcentaje -BackgroundColor red -ForegroundColor white
}

}

}
################## PRINCIPAL


# pregunto si hay parametros de mas, si los hay sale
if($inicio_resto -eq $TRUE)
{

    # si es igual a -1, no realiza impotar
    if($porcentaje_libre -eq -1)
    {
    exportar-CSV $path_export
    }
    # si ingreso un porcentaje se debe importar-
    else
    {
    importar-CSV $path_export $porcentaje_libre
    }

}
else
{
write-host "INGRESO PARAMETROS DE MAS CONSULTE Get-Help"
}
